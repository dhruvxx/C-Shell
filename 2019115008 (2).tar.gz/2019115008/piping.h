int checkpipe(char * commands);
void pipes(char * commands);
