void ctrlz ();
void ctrlc ();
void back (char * command);
void fore (char * command);