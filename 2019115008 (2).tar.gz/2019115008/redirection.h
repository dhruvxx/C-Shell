int redir(char * commands);
void red(char * commands);